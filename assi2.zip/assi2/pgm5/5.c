#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<string.h>
#include<sys/stat.h>
		
int main(int argc,char*argv[])
{
	pid_t pid=0;
	pid_t sid=0;
	FILE *fp=NULL;
        int i=0;
 	pid=fork();//new child process creted
	
	if(pid<0)
        {
		printf("child process faild");
		exit(1);
	}

	if(pid>0)
	{
		printf("pid of child process %d\n",pid);
		exit(0);
	}
 umask(0);//unmasking the file mode

 	sid=setsid();
	if(sid<0)
	{
		exit(1);
	}

	close(STDIN_FILENO);
	close(STDOUT_FILENO);
	close(STDERR_FILENO);

	fp=fopen("demo.txt","w+");
  	while(i<10)
	{
		sleep(10);
		fprintf(fp,"%d",i);
		i++;
	}
	fclose(fp);

	return 0;
}

