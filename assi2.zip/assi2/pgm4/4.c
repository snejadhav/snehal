#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>


int new(int argc,char*argv[])
{
      
	int i=0;
        pid_t pid;
       

        pid=fork();
       

        if(pid<0)
        {
                printf("fork failed");
                return -1;
        }
  
	if (fork()==0)
	{
	for(i=1;i<=2;i++)
	{
	  printf("child process %d\n",i);
 	}
	}
	else
	{
	 printf("parent process %d\n",i);
	}

	return 0;
}
 int  main()
{       
        int status;
        int parent_status;
	int child_status;
	char*arg_list[]={"ls","-1","/",NULL};
{        
      if (wait (&child_status))
{
        if (WIFEXITED(child_status))
        {
	    printf("the child process exited normally,with exit code %d\n");
	}
        else
	{
	    printf("child process exited abnormally\n");
	}
}
	else
       (WIFEXITED(parent_status));
        {
            printf("parent process terminated\n");
            fflush(stdout);
            wait(&status);
}     
}
     return 0;
}
     

