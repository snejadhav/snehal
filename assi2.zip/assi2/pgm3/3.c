#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>


int main(int argc,char*argv[])
{
      
	int i=0;
        pid_t pid;
       

        pid=fork();
       

        if(pid<0)
        {
                printf("fork failed");
                return -1;
        }
  
	if (fork()==0)
	{
	for(i=1;i<=3;i++)
	{
	  printf("child process %d\n",i);
 	}
	}
	else
	{
	 printf("parent process %d\n",i);
	}

	return 0;
}





