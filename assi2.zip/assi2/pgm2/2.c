#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>


int main(int argc,char*argv[])
{
   

        pid_t pid;
        pid_t pidb;
        int status;

        pid=fork();
       

        if(pid<0)
        {
                printf("fork failed");
                return -1;
       } 
	if (pid==0)
	   {
   		pidb=fork();
		printf("child  created %d\n",pid);
	        int status2;
	if (pidb==0)
	   {
		printf("child of process1 created %d\n",pidb);
	   }
	
	else 
	   {
 		printf("parent process %d\n",pid);
 		fflush(stdout);
                wait(&status);
	   }
}
 return 0;
}

























