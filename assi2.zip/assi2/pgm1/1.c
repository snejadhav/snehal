#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>


int spwan(char*pgm,char**arg_list)
{
	pid_t child_pid;
	child_pid=fork();
	if (child_pid!=0)
	{
	   printf("this is parent process");
	
         return child_pid;
 	}
	else
	{
	 execvp(pgm,arg_list);
	 printf("stderr,*an error occoured in execvp\n");
         abort();
	}
}
int main()
{
	int child_status;
	char*arg_list[]={"ls","-1","/",NULL};
        
        wait (&child_status);
        if (WIFEXITED(child_status))
        {
	    printf("the child process exited normally,with exit code %d\n");
	}
        else
	{
	    printf("child process exited abnormally\n");
	}
     return 0;
}
				
													
